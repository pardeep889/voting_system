<div class="pull-right hidden-xs">
      <a href="http://protolabzit.com"><b>Protolabz eServices</b></a>
    </div>
    <strong>Copyright &copy; 2018-2019 <a href="#">Voting System</a>.</strong> All rights reserved.