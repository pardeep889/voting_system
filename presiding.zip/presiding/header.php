<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Voting System</title>
    <!-- Bootstrap core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="../css/small-business.css" rel="stylesheet">

    <link rel="stylesheet" href="../css/login.css">
    <script
      src="https://code.jquery.com/jquery-3.3.1.js"
      integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
      crossorigin="anonymous"></script>
      <script type="text/javascript" src="js/pre.js"></script>
      <script type="text/javascript" src="js/sweet.js"></script>
      <script type="text/javascript" src="js/cam.js"> </script>
      <link href="css/master.css" rel="stylesheet">
  </head>
<?php include "../db/conn.php";
 ?>
